#' wdman.
#'
#' @name wdman
#' @importFrom assertthat assert_that
#' @importFrom binman process_yaml list_versions rm_platform
#'     rm_version app_dir
#' @docType package
NULL
