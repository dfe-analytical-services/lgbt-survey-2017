library(testthat)
library(binman)

test_check("binman")
